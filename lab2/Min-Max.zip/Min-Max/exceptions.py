class GameplayException(Exception):
    pass


class AgentException(Exception):
    pass
